import fs from "fs";
import express from "express";
import XLSX from "xlsx";

const app = express();
const BASE = process.cwd();
const LOG_FILE_WSP = `${BASE}/logs_wsp.json`;
const LOG_FILE_IG = `${BASE}/logs_ig.json`;
const RESERVO_FILE = `${BASE}/reservo_status.json`;

app.use(express.json());

// Registrar eventos
export function registrarEvento(origen, usuario, texto, respuesta) {
  const logFile = origen === "IG" ? LOG_FILE_IG : LOG_FILE_WSP;
  const registro = { usuario, mensaje: texto, respuesta, timestamp: Date.now() };
  const data = fs.existsSync(logFile) ? JSON.parse(fs.readFileSync(logFile, "utf8")) : [];
  data.push(registro);
  fs.writeFileSync(logFile, JSON.stringify(data, null, 2));
  console.log(`💬 Evento registrado en ${origen}: ${usuario}`);
}

function leer(file) {
  if (!fs.existsSync(file)) return [];
  return JSON.parse(fs.readFileSync(file, "utf8"));
}
function leerReservo() {
  if (!fs.existsSync(RESERVO_FILE)) return {};
  return JSON.parse(fs.readFileSync(RESERVO_FILE, "utf8"));
}

// Página principal
app.get("/", (req, res) => {
  const canal = req.query.canal || "whatsapp";
  const logs = leer(canal === "instagram" ? LOG_FILE_IG : LOG_FILE_WSP);
  const reservo = leerReservo();

  const usuarios = {};
  for (const log of logs) {
    if (!usuarios[log.usuario]) usuarios[log.usuario] = [];
    usuarios[log.usuario].push(log);
  }

  const lista = Object.keys(usuarios).map(u => {
    const ult = usuarios[u].slice(-1)[0];
    const hora = new Date(ult.timestamp).toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"});
    const estado = reservo[u]?.estado || "pendiente";
    const color =
      estado === "nuevo" ? "🟦" :
      estado === "confirmada" ? "🟩" :
      estado === "visitado" ? "🟨" :
      "🟥";
    return `<div class="usuario" onclick="abrirChat('${u}')">
      <div class="user-name">${color} ${u}</div>
      <div class="hora">${hora}</div>
      <div class="preview">${ult.mensaje.slice(0,40)}</div>
    </div>`;
  }).join("");

  res.send(`
  <html>
  <head>
    <meta charset="utf-8">
    <title>Monitor Zara 2.0</title>
    <style>
      body{margin:0;font-family:Arial;display:flex;height:100vh;}
      nav{background:#075E54;color:white;padding:10px;display:flex;justify-content:space-between;align-items:center;}
      button{background:#25D366;border:none;padding:8px 12px;color:white;border-radius:6px;cursor:pointer;margin-left:4px;}
      .sidebar{width:25%;background:#f5f5f5;border-right:1px solid #ccc;overflow-y:auto;display:flex;flex-direction:column;}
      .usuario{padding:10px;border-bottom:1px solid #ddd;cursor:pointer;}
      .usuario:hover{background:#e9e9e9;}
      .chat{flex:1;display:flex;flex-direction:column;background:#fff;}
      .mensajes{flex:1;padding:20px;overflow-y:auto;display:flex;flex-direction:column;gap:12px;}
      .msg{max-width:70%;padding:10px 14px;border-radius:10px;word-wrap:break-word;}
      .user{background:#dcf8c6;align-self:flex-end;}
      .bot{background:#f0f0f0;align-self:flex-start;}
      table{border-collapse:collapse;width:100%;margin-top:10px;}
      td,th{border:1px solid #ccc;padding:6px;text-align:left;}
    </style>
  </head>
  <body>
    <div class="sidebar">
      <nav>
        <div><b>Panel</b></div>
        <div>
          <button onclick="mostrar('whatsapp')">WSP</button>
          <button onclick="mostrar('instagram')">IG</button>
          <button onclick="mostrar('dashboard')">📊</button>
          <button onclick="actualizar()">🔄</button>
        </div>
      </nav>
      <div id="usuarios">${lista || "<p style='padding:10px'>Sin mensajes</p>"}</div>
    </div>

    <div class="chat">
      <nav id="nombreChat"><b>Selecciona un usuario</b></nav>
      <div id="mensajes" class="mensajes"></div>
      <div id="dashboard" style="display:none;padding:20px;overflow-y:auto;"></div>
    </div>

    <script>
      const data=${JSON.stringify(usuarios)};
      function abrirChat(usuario){
        document.getElementById('nombreChat').innerHTML=usuario;
        const msgs=data[usuario]||[];
        document.getElementById('mensajes').innerHTML=msgs.map(m=>
          '<div class="msg user">'+m.mensaje+'</div><div class="msg bot">'+m.respuesta+'</div>'
        ).join('');
      }
      async function actualizar(){
        const r=await fetch(location.href);
        const t=await r.text();
        const parser=new DOMParser();
        const html=parser.parseFromString(t,'text/html');
        document.getElementById('usuarios').innerHTML=html.getElementById('usuarios').innerHTML;
      }
      function mostrar(sec){
        document.getElementById('mensajes').style.display=sec==='dashboard'?'none':'block';
        document.getElementById('dashboard').style.display=sec==='dashboard'?'block':'none';
        if(sec==='dashboard') cargarDashboard();
      }
      async function cargarDashboard(){
        const r=await fetch('/dashboard');
        const d=await r.json();
        const c=document.getElementById('dashboard');
        c.innerHTML=\`
          <h3>📊 Funnel de Conversión</h3>
          <div>
            <label>Inicio:</label><input type="date" id="f1" value="\${d.def.inicio}">
            <label>Fin:</label><input type="date" id="f2" value="\${d.def.fin}">
            <select id="camp"><option value="">Todas las campañas</option>\${d.campanias.map(c=>\`<option>\${c}</option>\`).join('')}</select>
            <button onclick="filtrar()">Aplicar</button>
            <button onclick="exportar()">⬇ Exportar Excel</button>
          </div>
          <table>
            <tr><th>Etapa</th><th>Cantidad</th><th>%</th></tr>
            <tr><td>Total Leads</td><td>\${d.total}</td><td>100%</td></tr>
            <tr><td>🟦 Seguidores nuevos</td><td>\${d.azul}</td><td>\${d.pct.azul}%</td></tr>
            <tr><td>🟥 Por contactar</td><td>\${d.rojo}</td><td>\${d.pct.rojo}%</td></tr>
            <tr><td>🟨 Pendientes de agendar</td><td>\${d.amarillo}</td><td>\${d.pct.amarillo}%</td></tr>
            <tr><td>🟩 Agendados</td><td>\${d.verde}</td><td>\${d.pct.verde}%</td></tr>
          </table>\`;
      }
      async function filtrar(){
        const f1=document.getElementById('f1').value;
        const f2=document.getElementById('f2').value;
        const camp=document.getElementById('camp').value;
        const q=new URLSearchParams({inicio:f1,fin:f2,camp});
        const r=await fetch('/dashboard?'+q);
        const d=await r.json();
        const c=document.getElementById('dashboard');
        c.innerHTML=\`
          <h3>📊 Funnel de Conversión (Filtrado)</h3>
          <table>
            <tr><th>Etapa</th><th>Cantidad</th><th>%</th></tr>
            <tr><td>Total Leads</td><td>\${d.total}</td><td>100%</td></tr>
            <tr><td>🟦 Seguidores nuevos</td><td>\${d.azul}</td><td>\${d.pct.azul}%</td></tr>
            <tr><td>🟥 Por contactar</td><td>\${d.rojo}</td><td>\${d.pct.rojo}%</td></tr>
            <tr><td>🟨 Pendientes de agendar</td><td>\${d.amarillo}</td><td>\${d.pct.amarillo}%</td></tr>
            <tr><td>🟩 Agendados</td><td>\${d.verde}</td><td>\${d.pct.verde}%</td></tr>
          </table>\`;
      }
      function exportar(){
        const f1=document.getElementById('f1').value;
        const f2=document.getElementById('f2').value;
        const camp=document.getElementById('camp').value;
        window.open('/dashboard/excel?inicio='+f1+'&fin='+f2+'&camp='+camp,'_blank');
      }
    </script>
  </body>
  </html>
  `);
});

// --- backend del dashboard ---
app.get("/dashboard",(req,res)=>{
  const inicio=req.query.inicio?new Date(req.query.inicio):new Date(Date.now()-86400000);
  const fin=req.query.fin?new Date(req.query.fin):new Date();
  fin.setHours(23,59,59,999);
  const camp=req.query.camp||"";
  const logs=leer(LOG_FILE_IG);
  const reservo=leerReservo();
  const campanias=[...new Set(logs.map(l=>l.campaña).filter(Boolean))];
  let cont={azul:0,rojo:0,amarillo:0,verde:0};
  for(const u of Object.keys(reservo)){
    const e=reservo[u].estado;
    if(e==="nuevo")cont.azul++;
    else if(e==="pendiente")cont.rojo++;
    else if(e==="visitado")cont.amarillo++;
    else if(e==="confirmada")cont.verde++;
  }
  const total=cont.azul+cont.rojo+cont.amarillo+cont.verde;
  const pct={};
  for(const k of ["azul","rojo","amarillo","verde"]) pct[k]=total?(cont[k]*100/total).toFixed(1):0;
  res.json({total,...cont,pct,def:{inicio:inicio.toISOString().slice(0,10),fin:fin.toISOString().slice(0,10)},campanias});
});

// --- exportar a Excel ---
app.get("/dashboard/excel",(req,res)=>{
  const data=leerReservo();
  const rows=Object.entries(data).map(([u,v])=>({
    Usuario:u,
    Estado:v.estado,
    Fecha:v.fecha||"",
    Hora:v.hora||"",
    Tratamiento:v.tratamiento||""
  }));
  const ws=XLSX.utils.json_to_sheet(rows);
  const wb=XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb,ws,"Funnel BodyElite");
  const buffer=XLSX.write(wb,{type:"buffer",bookType:"xlsx"});
  res.setHeader("Content-Disposition","attachment; filename=funnel_bodyelite.xlsx");
  res.setHeader("Content-Type","application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
  res.send(buffer);
});

export function iniciarMonitor(){
  const PORT=4000;
  app.listen(PORT,()=>console.log("📊 Monitor activo en http://localhost:"+PORT));
}
