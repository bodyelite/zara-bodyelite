import { registrarEvento } from "./monitorChat.js";

// Registra mensajes reales provenientes del webhook (WhatsApp o Instagram)
export function registrarDesdeWebhook(mensajeEntrante) {
  try {
    const origen = mensajeEntrante.channel === "instagram" ? "instagram" : "whatsapp";
    const usuario = mensajeEntrante.from || mensajeEntrante.username || "desconocido";
    const texto = mensajeEntrante.text?.body || mensajeEntrante.message || "";
    const respuesta = mensajeEntrante.respuesta || "";

    registrarEvento(origen, usuario, texto, respuesta);
    console.log(`🩵 Registro automático (${origen}) → ${usuario}`);
  } catch (err) {
    console.error("❌ Error registrando remitente:", err.message);
  }
}
