import express from "express";
import whatsappListener from "./core/whatsappListener.js";
import { iniciarMonitor } from "./monitorChat.js";

const app = express();
app.use("/webhook", whatsappListener);
iniciarMonitor();

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`✅ Servidor activo en http://localhost:${PORT}`));
